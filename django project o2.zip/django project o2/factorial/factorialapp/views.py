from django.shortcuts import render

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

def index(request):
    result = None
    if request.method == 'POST':
        number = int(request.POST['number'])
        result = factorial(number)
    return render(request, 'factorialapp/index.html', {'result': result})
